"use client"

import { Navbar } from "@/components/navbar"
import { useTheme } from "next-themes"
import { Card } from "@/components/ui/card"

export default function Home() {
  const { theme, setTheme } = useTheme()

  const handleLogout = () => {
    console.log("Logging out...")
    // In a real app, this would handle the logout process
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar
        showSearch={true}
        showThemeToggle={true}
        showLanguageSelector={true}
        showUserMenu={true}
        showBalance={true}
        showCreateButton={true}
        balance={1547.4} // Changed to positive value
        user={{
          name: "John Doe",
          email: "john@example.com",
          initials: "JD",
        }}
        isDark={theme === "dark"}
        onThemeToggle={(newTheme) => setTheme(newTheme || "system")}
        onLogout={handleLogout}
      />
      <main className="flex-1 container py-12">
        <h1 className="text-4xl font-bold mb-6">Welcome to REVA</h1>
        <p className="text-lg text-muted-foreground mb-8">A powerful platform for all your needs</p>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="p-6 card-glass">
              <h2 className="text-xl font-semibold mb-2">Feature {i + 1}</h2>
              <p className="text-muted-foreground">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </Card>
          ))}
        </div>
      </main>
    </div>
  )
}

