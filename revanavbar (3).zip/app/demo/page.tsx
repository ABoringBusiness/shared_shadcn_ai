"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { useTheme } from "next-themes"
import { Card } from "@/components/ui/card"

export default function DemoPage() {
  const { theme, setTheme } = useTheme()
  const [showSearch, setShowSearch] = useState(true)
  const [showThemeToggle, setShowThemeToggle] = useState(true)
  const [showLanguageSelector, setShowLanguageSelector] = useState(true)
  const [showUserMenu, setShowUserMenu] = useState(true)
  const [showBalance, setShowBalance] = useState(true)
  const [showCreateButton, setShowCreateButton] = useState(true)
  const [showNotifications, setShowNotifications] = useState(false)
  const [showMessages, setShowMessages] = useState(false)

  const handleLogout = () => {
    console.log("Logging out...")
    // In a real app, this would handle the logout process
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar
        showSearch={showSearch}
        showThemeToggle={showThemeToggle}
        showLanguageSelector={showLanguageSelector}
        showUserMenu={showUserMenu}
        showBalance={showBalance}
        showCreateButton={showCreateButton}
        showNotifications={showNotifications}
        showMessages={showMessages}
        balance={1547.4} // Changed to positive value
        user={{
          name: "John Doe",
          email: "john@example.com",
          initials: "38",
        }}
        isDark={theme === "dark"}
        onThemeToggle={(newTheme) => setTheme(newTheme || "system")}
        onLogout={handleLogout}
      />

      <main className="flex-1 container py-12">
        <h1 className="text-4xl font-bold mb-6">Navbar Demo</h1>
        <p className="text-lg text-muted-foreground mb-8">Customize the navbar by toggling different features</p>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mb-8">
          <div className="flex items-center gap-2">
            <input type="checkbox" id="showSearch" checked={showSearch} onChange={() => setShowSearch(!showSearch)} />
            <label htmlFor="showSearch">Show Search</label>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="showThemeToggle"
              checked={showThemeToggle}
              onChange={() => setShowThemeToggle(!showThemeToggle)}
            />
            <label htmlFor="showThemeToggle">Show Theme Toggle</label>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="showLanguageSelector"
              checked={showLanguageSelector}
              onChange={() => setShowLanguageSelector(!showLanguageSelector)}
            />
            <label htmlFor="showLanguageSelector">Show Language Selector</label>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="showUserMenu"
              checked={showUserMenu}
              onChange={() => setShowUserMenu(!showUserMenu)}
            />
            <label htmlFor="showUserMenu">Show User Menu</label>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="showBalance"
              checked={showBalance}
              onChange={() => setShowBalance(!showBalance)}
            />
            <label htmlFor="showBalance">Show Balance</label>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="showCreateButton"
              checked={showCreateButton}
              onChange={() => setShowCreateButton(!showCreateButton)}
            />
            <label htmlFor="showCreateButton">Show Create Button</label>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="showNotifications"
              checked={showNotifications}
              onChange={() => setShowNotifications(!showNotifications)}
            />
            <label htmlFor="showNotifications">Show Notifications</label>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="showMessages"
              checked={showMessages}
              onChange={() => setShowMessages(!showMessages)}
            />
            <label htmlFor="showMessages">Show Messages</label>
          </div>
        </div>

        <Card className="p-6 card-glass">
          <h2 className="text-xl font-semibold mb-4">Usage Example</h2>
          <pre className="p-4 rounded bg-muted overflow-x-auto">
            {`<Navbar 
  showSearch={${showSearch}}
  showThemeToggle={${showThemeToggle}}
  showLanguageSelector={${showLanguageSelector}}
  showUserMenu={${showUserMenu}}
  showBalance={${showBalance}}
  showCreateButton={${showCreateButton}}
  showNotifications={${showNotifications}}
  showMessages={${showMessages}}
  balance={1547.4}
  user={{
    name: "John Doe",
    email: "john@example.com",
    initials: "38",
  }}
  isDark={theme === "dark"}
  onThemeToggle={(newTheme) => setTheme(newTheme || "system")}
  onLogout={handleLogout}
/>`}
          </pre>
        </Card>
      </main>
    </div>
  )
}

