import { Navbar } from "@/components/navbar"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar
        showSearch={true}
        showThemeToggle={true}
        showLanguageSelector={true}
        showUserMenu={true}
        showBalance={true}
        showCreateButton={true}
        balance={-1547.4}
        user={{
          name: "John Doe",
          email: "john@example.com",
          initials: "38",
        }}
      />
      <main className="flex-1 container py-12">
        <h1 className="text-4xl font-bold mb-6">Welcome to REVA</h1>
        <p className="text-lg text-muted-foreground mb-8">A powerful platform for all your needs</p>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="rounded-lg border bg-card p-6">
              <h2 className="text-xl font-semibold mb-2">Feature {i + 1}</h2>
              <p className="text-muted-foreground">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}

